package model;

public class Dealer extends Player{
	/**
	 * constructeur sans parametre de dealer
	 */
	public Dealer(String nom){
		super(nom);
	}
	/**
	 * fonction peremetant au dealer de miser
	 */
	public void mise(int choix){
		
	}
	/**
	 * 	fonction distribuant les cartes
	 */
	public void distribue(){
	}
}
