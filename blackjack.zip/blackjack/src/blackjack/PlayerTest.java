package blackjack;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import model.Player;

public class PlayerTest {
	Player amelie,benoit,humbert;
	@Before
	public void setUp(){
		amelie = new Player(150, "Am�lie");
		benoit = new Player("Benoit");
		humbert = new Player(0, "Humbert");
	}
	@Test
	public void test() {
		amelie.mise(5);
		assertEquals(145, amelie.getMoney(),0);
		assertEquals("Am�lie", amelie.getNom());
		assertEquals(false, amelie.isWin());
		assertEquals(false, amelie.isFin());
		amelie.mise(100);
		assertEquals(100, amelie.getMiseAct());
		
		benoit.mise(5);
		assertEquals(1495, benoit.getMoney(),0);
		assertEquals("Benoit", benoit.getNom());
		assertFalse(benoit.isWin());
		assertFalse(benoit.isFin());
		benoit.mise(2000);
		assertEquals(0, benoit.getMiseAct());
		
		humbert.mise(120);
		assertEquals(0, humbert.getMoney(),0);
		assertEquals("Humbert", humbert.getNom());
		assertFalse(humbert.isWin());
		assertFalse(humbert.isFin());
		humbert.mise(0);
		assertEquals(0, humbert.getMiseAct());
	}

}
