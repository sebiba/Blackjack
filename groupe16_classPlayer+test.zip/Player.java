package blackjack;

import javax.swing.JOptionPane;
/**
 * groupe 16 Blackjack
 * @author S�bastien Blacks
 *cette classe repr�sente un joueur de blackjack ayant de l'argent un nom et une mise
 */

public class Player extends Game{
	private int money;
	private boolean win;
	private String nom;
	private int miseAct;
	/**
	 * constructeur sans argument de la classe
	 */
	public Player(){
		this.money=1500;
		this.win=false;
		this.nom=JOptionPane.showInputDialog("entrez un nom pour le joueur");
		this.miseAct=0;
	}
	/**
	 * constructeur avec comme argument
	 * @param money l'argent donn� a la personne en d�but de partie
	 * @param nom du joueur
	 */
	public Player(int money, String nom){
		this.money=money;
		this.win=false;
		this.nom=nom;
		this.miseAct=0;
	}
	/**
	 * fonction verifiant si la mise voulue est plus grande que l'argent du joueur et traite la mise du joueur
	 * @param choix montant voulu de mise
	 */
	public void mise(int choix){
		if(choix<=money){
			super.addMise();
			this.money=this.money-choix;
			this.miseAct=choix;
		}else{
			System.out.println("vous ne pouvez pas misez ce montant...");
			int rechoix =Integer.parseInt(JOptionPane.showInputDialog("entrez une mise"));
			mise(rechoix);
		}
	}
	/**
	 * retourne la valeur de money
	 * @return
	 */
	public int getMoney() {
		return money;
	}
	/**
	 * atribue une valeur a money
	 * @param money 
	 */
	public void setMoney(int money) {
		this.money = money;
	}
	/**
	 * retourne true si le joueur a gagn� la manche false si il a perdu
	 * @return
	 */
	public boolean isWin() {
		return win;
	}
	/**
	 * atribue un valeur bool�enne a win 
	 * @param win true si gagnant false si perdant
	 */
	public void setWin(boolean win) {
		this.win = win;
	}
	/**
	 * retourne le nom du joueur
	 * @return
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * atribue un nom au joueur
	 * @param nom
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
}
